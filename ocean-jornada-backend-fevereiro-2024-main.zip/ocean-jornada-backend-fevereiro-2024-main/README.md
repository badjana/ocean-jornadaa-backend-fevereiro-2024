# ocean-jornada-backend-fevereiro-2024
Projeto com NodeJS e Express feito para a Jornada Backend do Samsung Ocean em Fevereiro de 2024.
